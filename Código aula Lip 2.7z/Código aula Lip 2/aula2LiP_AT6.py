num = input()
numSeparado = ""

for digito in num: 
    numSeparado += f"{digito}   "

print(numSeparado)