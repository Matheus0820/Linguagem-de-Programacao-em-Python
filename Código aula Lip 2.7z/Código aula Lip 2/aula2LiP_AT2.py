print("number	square	cube")
for i in range(0, 6):
    print(f"{i}	{i**2}	{i**3}")