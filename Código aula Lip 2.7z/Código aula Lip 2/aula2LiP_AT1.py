pi = 3.14159
raio = int(input())

# Diametro
print(f"Diâmetro = {2*raio}")

# Circunferência
print(f"Circunferência = {2*raio*pi:.5f}")

# Área
print(f"Área = {(raio**2)*pi}")